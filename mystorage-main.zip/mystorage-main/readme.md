<h1 align="center">Welcome<img src="https://user-images.githubusercontent.com/1303154/88677602-1635ba80-d120-11ea-84d8-d263ba5fc3c0.gif" width="40px" alt=""><br></h1>
<p align="center">Simple RDP Google Colab</p>

<br>

## Example 
<a href="https://colab.research.google.com/github/rizzlydev/mystorage/blob/main/xrdp.ipynb#scrollTo=vk2qtOTGIFsQ" target="_parent"><img src="https://colab.research.google.com/assets/colab-badge.svg" alt="Deploy in google colab."/></a>

## Installing
- Fork This Repo
- Don't forget to give star! :3
- Visit [ngrok.com](https://dashboard.ngrok.com/auth/your-authtoken) Copy and Paste Your Authtoken
- Change Ngrok Authtoken in [`./autosetngrok.sh`](https://github.com/RizzyFuzz/mystorage/blob/main/autosetngrok.sh)
- Deploy your repo on [google colab](https://colab.research.google.com/github)
- Enjoy~

### Highlight
-   [x] Simple & easy to using
-   [x] But Ngrok Server is so slow, maybe the rdp is a bit delay (in android device).
-   [x] Random project to learning jupyter notebook & shell/bash, im bored heheh X3

### **Preview**
<p align="center">
    <img alt="Preview" src="https://raw.githubusercontent.com/RizzyFuzz/mystorage/main/screenshot.jpg">
</p>


